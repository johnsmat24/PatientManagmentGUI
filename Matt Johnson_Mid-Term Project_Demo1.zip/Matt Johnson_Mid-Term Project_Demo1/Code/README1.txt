Patient Management System � How to run code
* To open and connect with the database you will need to download JavaDB(Derby) for Netbeans. To do that follow the below instructions:
o Follow the link and download the lib .zip flie
* https://mirror.csclub.uwaterloo.ca/apache/db/derby/db-derby-10.14.2.0/
o Unzip this file to any location.
o Drag the Patient Management Database folder into this folder
* Open netbeans, select the services tab, expand the Database entry, right-click on JavaDB, select priorities. A window will pop up. For the Java DB installation, enter the directory path of where you unzipped the derby library file. For the Database location, you can choose any directory path or folder you would like (this is where databases are stored).
* Once it is installed you can connect to the database. In the services menu, click on Databases to expand. Then, click on JavaDB to expand and find the patient management database. Right click on it and click connect to connect the database.
* Download the Patient Management Folder from GitHub and place it in the NetBeans Projects folder where your NetBeans projects are stored. Once Netbeans is open the project should be listed. After you are connected to the database you can right-click on the Patient Management GUI to click run the program.
Sign -in:
* To sign-in once the program is open, you can use one of 3 accounts.
o Doctor
* EmployeeID = 1
* Password = password
o Nurse
* EmployeeID = 200
* Password = password
o OfficeAdmin
* EmployeeID = 400
* Password = password
