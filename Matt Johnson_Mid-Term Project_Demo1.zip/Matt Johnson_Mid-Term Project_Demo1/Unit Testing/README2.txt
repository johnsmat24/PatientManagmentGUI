Unit testing:
To test the add patient use case, add a patient that is not on the table.
Then, try to add a patient who already has an ssn in the system.
Try to remove a patient who does not have an ssn in the system.
Remove a patient who has a ssn in the system
View patient health record. As a doctor or nurse, search for a patient ssn who is in the system.
If they are in the system, but do not have any health information, add health info. for them.
